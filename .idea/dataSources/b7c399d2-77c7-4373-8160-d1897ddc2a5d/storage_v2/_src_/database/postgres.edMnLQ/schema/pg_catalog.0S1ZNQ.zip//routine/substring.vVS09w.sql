create function substring(text, text, text) returns text
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$select pg_catalog.substring($1, pg_catalog.similar_to_escape($2, $3))$$;

alter function substring(text, text, text) owner to postgres;

